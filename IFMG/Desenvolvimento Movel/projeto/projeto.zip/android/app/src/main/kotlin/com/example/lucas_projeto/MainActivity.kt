package com.example.lucas_projeto

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
