class LoginSettings{
  void checkPermissions(){}
  void validUser(){}
}