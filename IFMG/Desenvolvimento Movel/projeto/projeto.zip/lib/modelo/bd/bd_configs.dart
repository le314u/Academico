class Configs{
  static final databaseName = "FluxoDB.db";
  static final databaseVersion = 1;
}