% 1-Verdadeiro, notação prefixada
% 2-Falso
% 3-Verdadeiro
% 4-Verdadeiro
% 5-Falsa
% 6-Verdadeiro (MAS NÂO SEI PORQUE)
% 7-Falso numero não é atomo
% 8-Verdadeiro pois a variavel pode receber o valor do atomo
% 9-Falso pois mesmo que a variavel possa recebar o atomo o atomo ela não pode ser dois atomos diferentes
% 10-Verdadeiro pois o primeiro futor é igual e a quantidade de argumentos tbm.
% 11-Verdadeiro igual a explicação '10'
% 12-Verdadeiro
% 13-Verdadeiro pois em ambos lados há uma lista não vazia
% 14-Verdadeiro
% 15-Verdadeiro% 1-Verdadeiro, notação prefixada
% 2-Falso
% 3-Verdadeiro
% 4-Verdadeiro
% 5-Falsa
% 6-Verdadeiro (MAS NÂO SEI PORQUE)
% 7-Falso numero não é atomo
% 8-Verdadeiro pois a variavel pode receber o valor do atomo
% 9-Falso pois messmo que a variavel possa recebar o atomo o atomo ela não pode ser dois atomos diferentes
% 10-Verdadeiro pois o primeiro futor é igual e a quantidade de argumentos tbm.
% 11-Verdadeiro igual a explicação '10'
% 12-Verdadeiro
% 13-Verdadeiro pois em ambos lados há uma lista não vazia
% 14-Verdadeiro
% 15-Verdadeiro