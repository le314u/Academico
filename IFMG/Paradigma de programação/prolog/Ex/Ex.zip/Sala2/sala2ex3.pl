False
True
False
True
False
True
False
True
False   %Não sei porque
False   %Não sei porque
True