#!/usr/bin/swipl

% Crie dois fatos para definir respectivamente linhas verticais e horizontais. Você pode definir fatos com nível inferior chamados "linha" e dentro de linhas outro chamado "ponto" criando assim um termo complexo.

%Não entendi a pergunta!