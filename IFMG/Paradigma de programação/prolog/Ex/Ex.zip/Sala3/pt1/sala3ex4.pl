#!/usr/bin/swipl

%Não entendi a pergunta