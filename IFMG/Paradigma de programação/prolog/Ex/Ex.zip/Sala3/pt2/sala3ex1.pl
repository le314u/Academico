#!/usr/bin/swipl

lista(Lista,E1,E2):-
    [E1,E2|T] = Lista.